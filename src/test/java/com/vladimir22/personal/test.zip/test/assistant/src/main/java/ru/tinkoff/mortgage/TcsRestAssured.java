package ru.tinkoff.mortgage;

/**
 * @author v.pronkin on 23.05.2018
 */
public class TcsRestAssured {


}
