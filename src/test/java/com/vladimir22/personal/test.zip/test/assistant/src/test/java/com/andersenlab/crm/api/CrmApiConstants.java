package com.andersenlab.crm.api;

/**
 * @author v.pronkin on 01.08.2018
 */
public class CrmApiConstants {



	public static final String  CRM_HOST= "http://localhost:8080";


}
