package ru.tinkoff.mortgage;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.UriBuilder;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

import static io.restassured.RestAssured.given;
import static java.time.format.DateTimeFormatter.ISO_DATE_TIME;
import static org.junit.runners.Parameterized.Parameter;
import static org.junit.runners.Parameterized.Parameters;

/**
 * @author v.pronkin on 23.05.2018
 */
@RunWith(value = Parameterized.class)
public class TcsRestAssuredTest {

	private final String URI = "http://localhost:8080/mortgage";

	private static String YODA_SESSIONID = "nIvjChnQZTWMMWzg1bH-8T-rg3nx--7O80WPotbnTJsyY3LRPzUbu3a3CbAp35obXmNCwdXDoZIs3p-BnPitzA";
	private static String TEST_SESSIONID = "testsession_3-JL3SHGBB"; // "testsession_3-JM3Y1HYC";
	private static String TEST_SESSIONID2 = "testsession_3-JL84OL2M";

	private static String CPSMASTER_SESSIONID = "GXOjkuIxA1asLlVQjOQjFT2XOEt5FcgtydGqUQn2O8p06PckB7yEKwf6xOWD_APqxTfeUDBTk96AIclpSWNOEQ";

	private static String WRONG_SESSIONID = "wrong_testsession";

	@Parameter(0)
	public String path;
	@Parameter(1)
	public String sessionId;

	@Parameters(name = "test {index}, url: {0}")
	public static Collection<Object[]> data() {
		return Arrays.asList(new Object[][]{

//				{"questionary/manage_offers/banks_decisions", TEST_SESSIONID2}
//				{"questionary/address/plain_address", TEST_SESSIONID2}
//				{"questionary/documents/bank_documents", TEST_SESSIONID2}
//				{"questionary/bank_documents", "testsession_3-JLZPVFRH"}
//				{"/questionary/magic_links/generate_magic_link/docs", TEST_SESSIONID2}
//				{"questionary/manager_info", TEST_SESSIONID}
//				{"cps/landing_url", TEST_SESSIONID}
//				{"questionary/coborrower/autocomplete_coborrower_assets", TEST_SESSIONID},
//				{"questionary/management/forbid_call_for_questionary", TEST_SESSIONID},
//				{"/cps/manage_order", CPSMASTER_SESSIONID},
//				{"/cps/ibul_register", CPSMASTER_SESSIONID}
//				{"/cps/manager_info", CPSMASTER_SESSIONID}
//				{"/cps/realtor_info"},
//				{"/organization_type"},
//				{"/cps/realtor_contacts", YODA_SESSIONID}
//				{"/self_service/evaluation_info", TEST_SESSIONID}
//				{"/self_service/evaluation_receipt", "testsession_3-JL3M4S0U"}
//				{"/self_service/steps_navigation", "testsession_3-JL84OL2M"}
//				{"/questionary/navigation_pages", TEST_SESSIONID}
//				{"/cps/registration/excel_register", YODA_SESSIONID}
//				{"/cps/check_answers", CPSMASTER_SESSIONID}
				{"/self_service/change_evaluation_status", TEST_SESSIONID}
//				{"/self_service/demand_questions", TEST_SESSIONID}
//				{"/self_service/choose_bank", "testsession_3-JLZRJZMK"}
//				{"/inquirer/suitable_and_rejected_banks", TEST_SESSIONID2}
//				{"cps/registration/add_partner", CPSMASTER_SESSIONID}
//				{"cps/sso_siebel_register", CPSMASTER_SESSIONID}
//				{"cps/assign_realtor", TEST_SESSIONID}
//				{"cps/reward/recommendations_report", CPSMASTER_SESSIONID}
//				{"/mobile/realtors_clients", CPSMASTER_SESSIONID}

//				{"/reappraisal/autocomplete_questionary_for_reappraisal", TEST_SESSIONID}
//				{"/reappraisal/pass_questionary_to_reappraise", TEST_SESSIONID}
		});
	}




//          -----------  Standart Methods ------------

//	@Test
//	public void getCallShouldBeSuccess() {
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//
//		given().log().all()
//				.when().get(request)
//				.then().log().all().statusCode(200);
//	}

//	@Test
//	public void getCallShouldBeUnsuccess() {
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", WRONG_SESSIONID).toTemplate();
//
//		given().log().all()
//				.when().get(request)
//				.then().log().all().body("errorCode", is("Forbidden")).statusCode(200);
//
//	}

//	@Test
//	public void postMultipartCallShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//
//
//		given().log().all().multiPart(new File("C:\\Users\\Пользователь\\Downloads\\excel_register_sample.xlsx"))
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}


// ---------- cps/sso_siebel_register   ----------

//	@Test
//	public void postMultipartCallShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//
//
//		given().log().all().multiPart(new File("C:\\Users\\Пользователь\\Downloads\\sso_siebel_register.xlsx"))
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}


//    ---------- /self_service/change_evaluation_status ----------
	@Data
	@Builder
	public static class SelfServiceChangeEvaluationStatusRequest {
		private String evaluationStatus;
	}

	@Test
	public void postJsonBodyCertificateQuestionAnswerShouldBeSuccess() {

		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
		given().log().all().body(SelfServiceChangeEvaluationStatusRequest.builder().evaluationStatus("Смена объекта").build()).contentType("application/json")
				.when().post(request)
				.then().log().all().statusCode(200);
	}



	//    ---------- /cps/ibul_register ----------
//	@Data
//	@Builder
//	static public class IbulRegisterRequest {
//		@NotNull
//		@Pattern(regexp = "[-\\p{InCyrillic}]+(\\s+[-\\p{InCyrillic}]+)+\\s*")
//		private String fio;
//		@NotEmpty
//		private String phone;
//		@Email(regexp = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])",
//				flags = Pattern.Flag.CASE_INSENSITIVE)
//		private String email;
//		@NotNull
//		private PartnerType partnerType;
//		private String innOrOgrn;
//		private String companyName;
//		private String comment;
//		private String invitedByAgentId;
//		private String promocode;
//		private List<SubordinateRealtor> subordinateRealtors;
//		private CollaborationType collaborationType;
//	}
//
//	public enum CollaborationType {
//		DEVELOPER("Застройщик"), REALTOR("Риэлтор");
//
//		private String name;
//		private static Map<String, CollaborationType> namesMap = new HashMap<>();
//
//		static {
//			namesMap.put("DEVELOPER", DEVELOPER);
//			namesMap.put("REALTOR", REALTOR);
//		}
//
//		CollaborationType(String name) {
//			this.name = name;
//		}
//
//		public String getName() {
//			return name;
//		}
//
//		@JsonCreator
//		public static CollaborationType forValue(String value) {
//			return namesMap.get(StringUtils.upperCase(value));
//		}
//
//		@JsonValue
//		public String toValue() {
//			for (Map.Entry<String, CollaborationType> entry : namesMap.entrySet()) {
//				if (entry.getValue() == this)
//					return entry.getKey();
//			}
//			return null;
//		}
//	}
//
//	@Data
//	@Builder
//	static public class SubordinateRealtor {
//		private String fio;
//		private String phone;
//		private String email;
//	}
//
//	public enum PartnerType {
//		COMPANY, PERSON;
//
//		private static Map<String, PartnerType> namesMap = new HashMap<>();
//
//		static {
//			namesMap.put("COMPANY", COMPANY);
//			namesMap.put("PERSON", PERSON);
//		}
//
//		@JsonCreator
//		public static PartnerType forValue(String value) {
//			return namesMap.get(StringUtils.upperCase(value));
//		}
//
//		@JsonValue
//		public String toValue() {
//			for (Map.Entry<String, PartnerType> entry : namesMap.entrySet()) {
//				if (entry.getValue() == this)
//					return entry.getKey();
//			}
//			return null;
//		}
//	}
//
//	@Test
//	public void postJsonBodyCertificateQuestionAnswerShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().body(
//				IbulRegisterRequest.builder()
//				.fio("Иванов Иван Иваныч").phone("+79211234567").email("vv.ilc@mail.ru").partnerType(PartnerType.COMPANY)
//				.innOrOgrn("2969700633").companyName("horns & копыта").comment("\"каментЫы жЖ Яя Ыы Ъъ Фф Йй Ёё №;%:?*()")
//				.invitedByAgentId("invitedByAgentId_1").promocode("promocode_1")
//				.subordinateRealtors(Arrays.asList(new SubordinateRealtor[]{SubordinateRealtor.builder().fio("Подчиненный Иван").phone("+79211234568").email("vv.ilc2@mail.ru").build()}))
//				.collaborationType(CollaborationType.REALTOR)
//				.build()
//		)
//			.contentType("application/json")
//			.when().post(request)
//			.then().log().all().statusCode(200);
//	}


//      ------------------------- /cps/check_answers --------------------------
//	@Data
//	@Builder
//	public static class CertificateQuestionAnswer {
//		private String question;
//		private List<String> answers;
//	}
//
//	@Test
//	public void postJsonBodyCertificateQuestionAnswerShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path("/cps/check_answers").queryParam("sessionid", CPSMASTER_SESSIONID).toTemplate();
//
//
//		CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build();
//
//
//
//		List<CertificateQuestionAnswer> certificateQuestionAnswers = new ArrayList<>();
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Какие данные мне достаточно предоставить по своему клиенту для оставления заявки?")
//				.answers(Arrays.asList(new String[]{"Контактные данные, данные по кредиту"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу вернуться в кабинет после оставления заявки?")
//				.answers(Arrays.asList(new String[]{"Открыть новую вкладку и открыть кабинета"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//		certificateQuestionAnswers.add(CertificateQuestionAnswer.builder().question("Как я могу восстановить логин и пароль?")
//				.answers(Arrays.asList(new String[]{"Только по почте, указанной в партнёрском кабинете"})).build());
//
//
//
//		given().log().all().body(certificateQuestionAnswers).contentType("application/json")
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}



// cps/add_partner


//	@Data
//	@Builder
//	@JsonIgnoreProperties(ignoreUnknown = true)
//	public static class CpsPartnerRequest {
//		@NotNull
//		private String secretKey;
//		private String ssoId;
//		@NotNull
//		private String siebelId;
//		@NotNull
//		private String phone;
//		@NotNull
//		private String email;
//		@NotNull
//		private String fullName;
//		private String registrationCode;
//		@NotNull
//		private String companyInn;
//		@NotNull
//		private String companySiebelId;
//		private String companySsoId;
//		@NotNull
//		private String registrationDate;
//		private String attractionSource;
//		private String attractionSubSource;
//	}
//
//	@Test
//	public void postCpsAddpartnerShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().body(
//				CpsPartnerRequest.builder()
//						.fullName("Иванов Иван Иваныч").phone("+79211234567").email("vv.ilc@mail.ru").companySiebelId("JL3SHGB2")
//						.companyInn("2969700633").secretKey("8DW10DTennant42Allons-y").siebelId("JL3SHGBB").registrationDate(LocalDateTime.now().format(ISO_DATE_TIME))
//						.build()
//		)
//				.contentType("application/json")
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}


/* ------------ /self_service/evaluation_receipt  ------------ */

//	@Data
//	@Builder
//	@JsonIgnoreProperties
//	static public class EvaluationReceiptRequest {
//
//		@ApiModelProperty(value = "детали платежа (провайдер, сумма, валюта")
//		private Receipt receipt;
//
//		@ApiModelProperty(value = "статус платежа", example = "OK")
//		private String paymentStatus;
//
//		@ApiModelProperty(value = "дополнительная информация о статусе платежа")
//		private String detailedStatus;
//
//		@ApiModelProperty(value = "дата совершения платежа", example = "2018-06-05")
//		private String paymentDate;
//	}
//
//	@Builder
//	@Data
//	static public class Receipt {
//
//		@ApiModelProperty(value = "id платежа для сохранания в базу данных", example = "45125A86d")
//		private String paymentId;
//
//		@ApiModelProperty("тип платежа")
//		private String paymentType;
//
//		@ApiModelProperty("название компании оказывающей услугу")
//		private String providerName;
//
//		@ApiModelProperty("информация о валюте и сумме платежа")
//		private Amount amount;
//	}
//
//	@Builder
//	@Data
//	static public class Amount {
//
//		@ApiModelProperty(value = "сумма платежа в валюте", example = "5500.49")
//		private Double value;
//
//		@ApiModelProperty(value = "информация о валюте")
//		private Currency currency;
//	}
//
//	@Builder
//	@Data
//	static public class Currency {
//
//		@ApiModelProperty(value = "код валюты", example = "RUB")
//		private String code;
//
//		@ApiModelProperty(value = "название валюты", example = "Рубли")
//		private String name;
//	}
//
//	@Test
//	public void postSelfServiceEvaluationRecieptShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().body(
//				EvaluationReceiptRequest.builder()
//						.receipt(
//								Receipt.builder().paymentId("45125A86d2").paymentType("Тип оплаты").providerName("Провайдер")
//
//										.amount(Amount.builder().value(1000.5).currency(Currency.builder().code("RUB").name("рубли").build())
//												.build())
//										.build()
//						)
//						.paymentStatus("OK").detailedStatus("Все хорошо").paymentDate("2018-01-15")
//						.build()
//		)
//				.contentType("application/json")
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}


// ------------------ cps/reward/recommendations_report ------------------
// ------------------ cps/reward/my_clients_report ------------------

//	@Test
//	public void getCpsRewardServiceShouldBeSuccess() {
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().param("startDate", "2018-01-01").param("finishDate","2018-06-01")
//				.contentType("application/json")
//				.when().get(request)
//				.then().log().all().statusCode(200);
//	}


	// ------------------ self_service/choose_bank ------------------

//	@Test
//	public void getCpsRewardServiceShouldBeSuccess() {
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().param("bankCode", "AIJK")
//				.contentType("application/json")
//				.when().get(request)
//				.then().log().all().statusCode(200);
//	}

//  ------------------  cps/assign_realtor   ------------------


//	@Builder
//	@Data
//	static public class RealtorsContactData {
//		private String fio;
//		private String phone;
//		private String email;
//		private Boolean isChangeable;
//		private Boolean isFioMatch;
//		private Boolean isEmailMatch;
//	}
//
//	@Test
//	public void postSelfServiceEvaluationRecieptShouldBeSuccess() {
//
//		String request = UriBuilder.fromUri(URI).path(path).queryParam("sessionid", sessionId).toTemplate();
//		given().log().all().body(
//				RealtorsContactData.builder()
//						.fio("Бровкин Владимир Викторович")
//						.phone("+78890124135").email("vv.ilc@mail.ru")
//						.build()
//		)
//				.contentType("application/json")
//				.when().post(request)
//				.then().log().all().statusCode(200);
//	}

}
