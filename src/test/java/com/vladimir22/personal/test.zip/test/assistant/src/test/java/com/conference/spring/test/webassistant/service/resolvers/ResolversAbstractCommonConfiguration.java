package com.conference.spring.test.webassistant.service.resolvers;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * @author tolkv
 * @version 02/04/2017
 */

@SpringBootTest
@ActiveProfiles("yegor_vs_jbaruch")
public abstract class ResolversAbstractCommonConfiguration {

}
