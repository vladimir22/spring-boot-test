package ru.tinkoff.mortgage.aijk.common;

import ru.tinkoff.mortgage.generated.aijk.model.Content;
import ru.tinkoff.mortgage.generated.aijk.model.DocumentWithContent;
import ru.tinkoff.mortgage.generated.aijk.model.FacadeFullAppApplicant;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.codehaus.groovy.vmplugin.v7.IndyGuardsFiltersAndSignatures.isNull;

/**
 * @author v.pronkin on 27.04.2018
 */
public class AijkObjectsHandler {

	public static void attachFullAppPersonContent(FacadeFullAppApplicant facadeFullAppPerson, String fileName, String contentType, byte[] uploadContent) {
		attachFullAppPersonContent(facadeFullAppPerson,fileName,contentType,uploadContent, null);
	}

	public static void attachFullAppPersonContent(FacadeFullAppApplicant facadeFullAppPerson, String fileName, String contentType, byte[] uploadContent, String contentUrl) {

		Content content = new Content();
		content.setUploadContent(new String(uploadContent, StandardCharsets.UTF_8));
		content.setFileName(fileName);
		content.setContentType(Content.ContentTypeEnum.fromValue(contentType)); // TODO MO-8 question: create converter Content.ContentTypeEnum
		content.setUrl(contentUrl);

		List<Content> collectionContent = new ArrayList<>(1);
		collectionContent.add(content);

		List<DocumentWithContent> documentWithContentList =  facadeFullAppPerson.getDocuments() == null? new ArrayList<>(1): facadeFullAppPerson.getDocuments();

		DocumentWithContent documentWithContent = new DocumentWithContent();
		documentWithContent.setContent(collectionContent);

		documentWithContentList.add(documentWithContent);

		facadeFullAppPerson.setDocuments(documentWithContentList);
	}


	public static void assignContentUrl(FacadeFullAppApplicant facadeFullAppPerson) {

		List<DocumentWithContent> documentWithContentList =  facadeFullAppPerson.getDocuments() == null? new ArrayList<>(1): facadeFullAppPerson.getDocuments();

		documentWithContentList.stream().flatMap(documentWithContent -> documentWithContent.getContent().stream())
				.filter(c -> isNull(c.getUrl())).forEach(content -> content.setUrl(String.join("_","contentUrl", content.getFileName())));

	}

}
