package com.andersenlab.crm.api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import javax.ws.rs.core.UriBuilder;
import java.io.File;
import java.util.Arrays;
import java.util.Collection;

import static com.andersenlab.crm.api.CrmApiConstants.CRM_HOST;
import static io.restassured.RestAssured.given;
import static io.restassured.config.EncoderConfig.encoderConfig;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;

/**
 * @author v.pronkin on 30.07.2018
 */
@RunWith(value = Parameterized.class)
public class CrmRestAssuredTest {

		@Parameterized.Parameter(0)
		public String path;


		@Parameterized.Parameters(name = "test {index}, url: {0}")
		public static Collection<Object[]> data() {
			return Arrays.asList(new Object[][]{
				{"storage/listFiles"}
			});
		}


	@Test
	public void storageUploadListDeleteShouldBeSuccess() {

		String fileName = "20180530_150922_screenpresso.jpg";

		given().when().log().all()
				.multiPart(new File("D:\\temp\\" + fileName))
				.post(UriBuilder.fromUri(CRM_HOST).path("storage/upload_file").toTemplate())
				.then().log().all()
				.statusCode(200);

//		given().log().all().when()
//				.get(UriBuilder.fromUri(CRM_HOST).path("storage/list_files").toTemplate())
//				.then().log().all()
//				.statusCode(200)
//				.body("data", Matchers.hasItem(fileName));
//
//
//		given().log().all()
//				.param("filePath", fileName)
//				.when()
//				.delete(UriBuilder.fromUri(CRM_HOST).path("storage/delete_file").toTemplate())
//				.then().log().all()
//				.statusCode(200);
//
//		given().log().all().when()
//				.get(UriBuilder.fromUri(CRM_HOST).path("storage/list_files").toTemplate())
//				.then().log().all()
//				.statusCode(200)
//				.body("data", not(Matchers.hasItem(fileName)));
	}



}
