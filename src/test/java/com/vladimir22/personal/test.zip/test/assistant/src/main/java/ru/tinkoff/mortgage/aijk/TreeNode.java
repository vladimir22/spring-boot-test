package ru.tinkoff.mortgage.aijk;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * @author v.pronkin on 02.07.2018
 */
@Builder
@AllArgsConstructor
@Data
public class TreeNode{
	int val;
	TreeNode left;
	TreeNode right;
}
