package com.gost_group.api;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.ws.rs.core.UriBuilder;
import java.io.File;
import java.util.Date;


import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.not;
import static com.gost_group.api.ApiConstants.*;

/**
 * @author v.pronkin on 01.08.2018
 */
@Slf4j
public class RestReportsTest {

//		@Parameterized.Parameter(0)
//		public String path;
//
//
//		@Parameterized.Parameters(name = "test {index}, url: {0}")
//		public static Collection<Object[]> data() {
//			return Arrays.asList(new Object[][]{
//					{"storage/listFiles"}
//			});
//		}


	public  String COOKIE ="Idea-f1f08a84=d66a33a4-56e9-49e8-8388-a503d38f732d; FLOWABLE_REMEMBER_ME=S0tLRDJGVTN6WFI5Q1dEaDl5VnNaUSUzRCUzRDpwVDRSNFJCODdwTGNMUmlvN3NNaGVBJTNEJTNE; ";


	private static final String USERNAME = "sys";
//	private static final String USERNAME = "manager";
	private static final String PASSWORD = "123456";

		@Before
		public void restAuth() {
			title("авторизируемся по пользователем : "+USERNAME);
			Response response = given().log().all().when()
					.header("Cookie",COOKIE)
					.body("{login: \""+USERNAME+"\", password: \""+PASSWORD+"\"}")
					.header("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36")
					.post(UriBuilder.fromUri(HOST).path("rest/auth").toTemplate())

					.then().log().all()
					.statusCode(200).extract().response();


			String cookieResponse = response.getHeader("Set-Cookie");
			COOKIE = COOKIE + cookieResponse;
//			System.out.println(COOKIE);
		}

	@Test
	public void getRequestShouldBeSuccess() {
		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/report/by-date-and-status").toTemplate())
				.then().log().all()
				.statusCode(200);
	}


	@Test
	public void getRequest2ShouldBeSuccess() {
		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/group/nsi").toTemplate())
				.then().log().all()
				.statusCode(200);

		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/group-id/1").toTemplate())
				.then().log().all()
				.statusCode(200);

	}

	@Test
	public void postFormDocumentFormDocumentVersionDTO() {
//
//		given().log().all().when()
//				.header("Cookie",COOKIE)
//				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/version/2").toTemplate())
//				.then().log().all()
//				.statusCode(200);




		Response response = given().log().all().when()
				.header("Cookie",COOKIE)
				.contentType("application/json")
				.body("{\n" +
						"  \"formDocumentId\": 5,\n" +
						"  \"formDocumentVersionId\": 1,\n" +
						"  \"formId\": 1,\n" +
						"  \"jsonData\": \"{\\\"id\\\": 2, \\\"body\\\": {\\\"commons_flat\\\": [{\\\"purpose\\\": \\\"Нести добро\\\", \\\"etajnost\\\": 12, \\\"entrances\\\": 2, \\\"build_year\\\": 1960, \\\"total_area\\\": 1525.7, \\\"living_area\\\": 460.32, \\\"useful_area\\\": 1056.46, \\\"iznos_v_proc\\\": 92.5, \\\"kolvo_kvartir\\\": 15, \\\"unliving_area\\\": 606.5, \\\"cap_repair_year\\\": 2002, \\\"production_area\\\": 270}], \\\"commons_indi\\\": [{\\\"count\\\": 1, \\\"point\\\": 1, \\\"comment\\\": \\\"Тепловой пункт\\\", \\\"indicator\\\": 1}, {\\\"count\\\": 3, \\\"point\\\": 2, \\\"comment\\\": \\\"Водомерный узел\\\", \\\"indicator\\\": 12}, {\\\"count\\\": 6, \\\"point\\\": 3, \\\"comment\\\": \\\"Тепловой ввод\\\", \\\"indicator\\\": 15}], \\\"Commons_flat2\\\": [{\\\"gassupply\\\": 1, \\\"heatsupply\\\": 2, \\\"electrifysupply\\\": 3}], \\\"final_results\\\": [{\\\"conclusion\\\": \\\"Зима близко\\\"}], \\\"scope_of_work\\\": [{\\\"fact\\\": 34.2, \\\"unit\\\": 4806189, \\\"point\\\": \\\"1.\\\", \\\"planned\\\": 45.8, \\\"indicator\\\": \\\"Ремонт кровли\\\"}, {\\\"fact\\\": 12.2, \\\"unit\\\": 4806193, \\\"point\\\": \\\"2.\\\", \\\"planned\\\": 24.8, \\\"indicator\\\": \\\"Ремонт чердачных помещений\\\"}, {\\\"point\\\": \\\"3.\\\", \\\"indicator\\\": \\\"Ремонт фасадов\\\"}, {\\\"fact\\\": 314.6, \\\"unit\\\": 4797815, \\\"planned\\\": 456.3, \\\"indicator\\\": \\\"ремонт и покраска\\\"}, {\\\"fact\\\": 131.2, \\\"unit\\\": 4806194, \\\"planned\\\": 135.5, \\\"indicator\\\": \\\"герметизация швов\\\"}], \\\"expluatation_results\\\": [{\\\"point\\\": \\\"1\\\", \\\"ii_date\\\": \\\"2018-07-10T19:28:12\\\", \\\"reason_of_faults\\\": \\\"пьяный прораб\\\", \\\"check_of_faults_repair\\\": true, \\\"common_types_of_faults\\\": \\\"трещина в котельной\\\"}, {\\\"point\\\": \\\"2\\\", \\\"ii_date\\\": \\\"2018-02-10T10:20:45\\\", \\\"reason_of_faults\\\": \\\"ржавая заслонка\\\", \\\"check_of_faults_repair\\\": false, \\\"common_types_of_faults\\\": \\\"прорвало трубу\\\"}]}, \\\"docId\\\": 3, \\\"formId\\\": 2, \\\"header\\\": {\\\"owner\\\": 4797825, \\\"title\\\": \\\"Акт готовности роддома к отопительному сезону 2017-2018\\\", \\\"address\\\": \\\"5-я Советская 19\\\", \\\"object_attachment\\\": \\\"Роддом\\\"}, \\\"period\\\": 1, \\\"status\\\": 2, \\\"created\\\": \\\"2018-08-17T19:13:50\\\", \\\"updated\\\": \\\"2018-08-17T19:13:52\\\", \\\"processId\\\": null, \\\"absolutPath\\\": \\\"form/heat_season/act_ready_consumer/3/2\\\", \\\"isAvailable\\\": true}\",\n" +
						"  \"owner\": 4797828,\n" +
						"  \"periodId\": 2\n" +
						"}")
				.post(UriBuilder.fromUri(HOST).path("/rest/form-document/actions/version").toTemplate())
				.then().log().all().statusCode(200).contentType("application/json")
				.extract().response();


	}

	@Test
	public void patchFormDocumentFormDocumentVersionDTO() {

		title("Создание нового FormDocument c новым FormDocumentVersion:");
		Response response = given().log().all().when()
				.header("Cookie",COOKIE)
				.contentType("application/json")
				.body("{\n" +
						"  \"formDocumentId\": 18,\n" +
						"  \"formDocumentVersionId\": 37,\n" +
						"  \"formId\": 2,\n" +
						"  \"jsonData\": \"{\\\"id\\\": 2, \\\"body\\\": {\\\"commons_flat\\\": [{\\\"purpose\\\": \\\"Нести добро\\\", \\\"etajnost\\\": 12, \\\"entrances\\\": 2, \\\"build_year\\\": 1960, \\\"total_area\\\": 1525.7, \\\"living_area\\\": 460.32, \\\"useful_area\\\": 1056.46, \\\"iznos_v_proc\\\": 92.5, \\\"kolvo_kvartir\\\": 15, \\\"unliving_area\\\": 606.5, \\\"cap_repair_year\\\": 2002, \\\"production_area\\\": 270}], \\\"commons_indi\\\": [{\\\"count\\\": 1, \\\"point\\\": 1, \\\"comment\\\": \\\"Тепловой пункт\\\", \\\"indicator\\\": 1}, {\\\"count\\\": 3, \\\"point\\\": 2, \\\"comment\\\": \\\"Водомерный узел\\\", \\\"indicator\\\": 12}, {\\\"count\\\": 6, \\\"point\\\": 3, \\\"comment\\\": \\\"Тепловой ввод\\\", \\\"indicator\\\": 15}], \\\"Commons_flat2\\\": [{\\\"gassupply\\\": 1, \\\"heatsupply\\\": 2, \\\"electrifysupply\\\": 3}], \\\"final_results\\\": [{\\\"conclusion\\\": \\\"Зима близко\\\"}], \\\"scope_of_work\\\": [{\\\"fact\\\": 34.2, \\\"unit\\\": 4806189, \\\"point\\\": \\\"1.\\\", \\\"planned\\\": 45.8, \\\"indicator\\\": \\\"Ремонт кровли\\\"}, {\\\"fact\\\": 12.2, \\\"unit\\\": 4806193, \\\"point\\\": \\\"2.\\\", \\\"planned\\\": 24.8, \\\"indicator\\\": \\\"Ремонт чердачных помещений\\\"}, {\\\"point\\\": \\\"3.\\\", \\\"indicator\\\": \\\"Ремонт фасадов\\\"}, {\\\"fact\\\": 314.6, \\\"unit\\\": 4797815, \\\"planned\\\": 456.3, \\\"indicator\\\": \\\"ремонт и покраска\\\"}, {\\\"fact\\\": 131.2, \\\"unit\\\": 4806194, \\\"planned\\\": 135.5, \\\"indicator\\\": \\\"герметизация швов\\\"}], \\\"expluatation_results\\\": [{\\\"point\\\": \\\"1\\\", \\\"ii_date\\\": \\\"2018-07-10T19:28:12\\\", \\\"reason_of_faults\\\": \\\"пьяный прораб\\\", \\\"check_of_faults_repair\\\": true, \\\"common_types_of_faults\\\": \\\"трещина в котельной\\\"}, {\\\"point\\\": \\\"2\\\", \\\"ii_date\\\": \\\"2018-02-10T10:20:45\\\", \\\"reason_of_faults\\\": \\\"ржавая заслонка\\\", \\\"check_of_faults_repair\\\": false, \\\"common_types_of_faults\\\": \\\"прорвало трубу\\\"}]}, \\\"docId\\\": 3, \\\"formId\\\": 2, \\\"header\\\": {\\\"owner\\\": 4797825, \\\"title\\\": \\\"Акт готовности роддома к отопительному сезону 2017-2018\\\", \\\"address\\\": \\\"5-я Советская 19\\\", \\\"object_attachment\\\": \\\"Роддом\\\"}, \\\"period\\\": 1, \\\"status\\\": 2, \\\"created\\\": \\\"2018-08-17T19:13:50\\\", \\\"updated\\\": \\\"2018-08-17T19:13:52\\\", \\\"processId\\\": null, \\\"absolutPath\\\": \\\"form/heat_season/act_ready_consumer/3/2\\\", \\\"isAvailable\\\": true}\",\n" +
						"  \"owner\": 4797828,\n" +
						"  \"periodId\": 2\n" +
						"}")
				.post(UriBuilder.fromUri(HOST).path("/rest/form-document/version").toTemplate())
				.then().log().all().statusCode(200).contentType("application/json")
				.extract().response();


		Long formDocumentId = response.jsonPath().getLong("formDocumentId");

		title("Добавление в существующий FormDocument (formDocumentId: "+formDocumentId+") c новым FormDocumentVersion:");
		response = given().log().all().when()
				.header("Cookie",COOKIE)
				.contentType("application/json")
				.body("{\n" +
						"  \"formDocumentId\": "+formDocumentId+",\n" +
						"  \"formDocumentVersionId\": 37,\n" +
						"  \"formId\": 2,\n" +
						"  \"jsonData\": \"{\\\"id\\\": 2, \\\"body\\\": {\\\"commons_flat\\\": [{\\\"purpose\\\": \\\"Нести добро (PATCHED formDocumentId:"+formDocumentId+"\\\", \\\"etajnost\\\": 12, \\\"entrances\\\": 2, \\\"build_year\\\": 1960, \\\"total_area\\\": 1525.7, \\\"living_area\\\": 460.32, \\\"useful_area\\\": 1056.46, \\\"iznos_v_proc\\\": 92.5, \\\"kolvo_kvartir\\\": 15, \\\"unliving_area\\\": 606.5, \\\"cap_repair_year\\\": 2002, \\\"production_area\\\": 270}], \\\"commons_indi\\\": [{\\\"count\\\": 1, \\\"point\\\": 1, \\\"comment\\\": \\\"Тепловой пункт\\\", \\\"indicator\\\": 1}, {\\\"count\\\": 3, \\\"point\\\": 2, \\\"comment\\\": \\\"Водомерный узел\\\", \\\"indicator\\\": 12}, {\\\"count\\\": 6, \\\"point\\\": 3, \\\"comment\\\": \\\"Тепловой ввод\\\", \\\"indicator\\\": 15}], \\\"Commons_flat2\\\": [{\\\"gassupply\\\": 1, \\\"heatsupply\\\": 2, \\\"electrifysupply\\\": 3}], \\\"final_results\\\": [{\\\"conclusion\\\": \\\"Зима близко\\\"}], \\\"scope_of_work\\\": [{\\\"fact\\\": 34.2, \\\"unit\\\": 4806189, \\\"point\\\": \\\"1.\\\", \\\"planned\\\": 45.8, \\\"indicator\\\": \\\"Ремонт кровли\\\"}, {\\\"fact\\\": 12.2, \\\"unit\\\": 4806193, \\\"point\\\": \\\"2.\\\", \\\"planned\\\": 24.8, \\\"indicator\\\": \\\"Ремонт чердачных помещений\\\"}, {\\\"point\\\": \\\"3.\\\", \\\"indicator\\\": \\\"Ремонт фасадов\\\"}, {\\\"fact\\\": 314.6, \\\"unit\\\": 4797815, \\\"planned\\\": 456.3, \\\"indicator\\\": \\\"ремонт и покраска\\\"}, {\\\"fact\\\": 131.2, \\\"unit\\\": 4806194, \\\"planned\\\": 135.5, \\\"indicator\\\": \\\"герметизация швов\\\"}], \\\"expluatation_results\\\": [{\\\"point\\\": \\\"1\\\", \\\"ii_date\\\": \\\"2018-07-10T19:28:12\\\", \\\"reason_of_faults\\\": \\\"пьяный прораб\\\", \\\"check_of_faults_repair\\\": true, \\\"common_types_of_faults\\\": \\\"трещина в котельной\\\"}, {\\\"point\\\": \\\"2\\\", \\\"ii_date\\\": \\\"2018-02-10T10:20:45\\\", \\\"reason_of_faults\\\": \\\"ржавая заслонка\\\", \\\"check_of_faults_repair\\\": false, \\\"common_types_of_faults\\\": \\\"прорвало трубу\\\"}]}, \\\"docId\\\": 3, \\\"formId\\\": 2, \\\"header\\\": {\\\"owner\\\": 4797825, \\\"title\\\": \\\"Акт готовности роддома к отопительному сезону 2017-2018\\\", \\\"address\\\": \\\"5-я Советская 19\\\", \\\"object_attachment\\\": \\\"Роддом\\\"}, \\\"period\\\": 1, \\\"status\\\": 2, \\\"created\\\": \\\"2018-08-17T19:13:50\\\", \\\"updated\\\": \\\"2018-08-17T19:13:52\\\", \\\"processId\\\": null, \\\"absolutPath\\\": \\\"form/heat_season/act_ready_consumer/3/2\\\", \\\"isAvailable\\\": true}\",\n" +
						"  \"owner\": 4797828,\n" +
						"  \"periodId\": 2\n" +
						"}")
				.patch(UriBuilder.fromUri(HOST).path("/rest/form-document/version").toTemplate())
				.then().log().all().statusCode(200).contentType("application/json")
				.extract().response();


	}



	@Test
	public void getRequest3ShouldBeSuccess() {
//		given().log().all().when()
//				.header("Cookie",COOKIE)
//				.get(UriBuilder.fromUri(HOST).path("rest/forms/group/1").toTemplate())
//				.then().log().all()
//				.statusCode(200);

		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/forms/tree/1").toTemplate())
				.then().log().all()
				.statusCode(200);

	}

	@Test
	public void getRequestPeriodShouldBeSuccess() {

		RestAssured.defaultParser = Parser.JSON;

		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/period/all").toTemplate())
				.then().log().all()
				.statusCode(200);

		Response response = given().log().all().when()
				.header("Cookie",COOKIE)
				.contentType("application/json")
				.body("{\n" +
						"    \"code\": \"test6\",\n" +
						"    \"name\": \"test6-2017-2018\",\n" +
						"    \"startDate\": \"Oct 10, 2017 12:00:00 AM\",\n" +
						"    \"endDate\": \"Apr 20, 2018 12:00:00 AM\",\n" +
						"    \"created\": \"Aug 17, 2018 5:34:06 PM\",\n" +
						"    \"updated\": \"Aug 17, 2018 5:34:09 PM\"\n" +
						"}\t\t")
				.post(UriBuilder.fromUri(HOST).path("rest/period").toTemplate())
				.then().log().all().statusCode(200).contentType("application/json")
				.extract().response();


		Long id = response.jsonPath().getLong("id");

		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/period/"+id).toTemplate())
				.then().log().all()
				.statusCode(200);

		given().log().all().when()
				.contentType("application/json")
				.header("Cookie",COOKIE)
				.body("{\n" +
						"    \"code\": \"test6-patched\",\n" +
						"    \"name\": \"test6-patched-2017-2018\",\n" +
						"    \"startDate\": \"Oct 10, 2017 12:00:00 AM\",\n" +
						"    \"endDate\": \"Apr 20, 2018 12:00:00 AM\",\n" +
						"    \"id\": "+id+",\n" +
						"    \"created\": \"Aug 17, 2018 5:34:06 PM\",\n" +
						"    \"updated\": \"Aug 17, 2018 5:34:09 PM\"\n" +
						"}\t\t")
//				.body(PeriodDTO.builder().code("test").name("test").startDate(new Date()).endDate(new Date()).build())
				.patch(UriBuilder.fromUri(HOST).path("rest/period").toTemplate())
				.then().log().all()
				.statusCode(200);


		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/period/"+id).toTemplate())
				.then().log().all()
				.statusCode(200);


		given().log().all().when()
				.header("Cookie",COOKIE)
				.param("limit", 10).param("offset", 2)
				.get(UriBuilder.fromUri(HOST).path("rest/period/all").toTemplate())
				.then().log().all()
				.statusCode(200);

		given().log().all().when()
				.header("Cookie",COOKIE)
				.delete(UriBuilder.fromUri(HOST).path("rest/period/"+id).toTemplate())
				.then().log().all()
				.statusCode(200);

		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("rest/period/all").toTemplate())
				.then().log().all()
				.statusCode(200);
	}

	@Test
	public void getFormDocumentVersionsMustBeSuccess(){

//		given().log().all().when()
//				.header("Cookie",COOKIE)
//				.param("filter[form_id]", 1)
//				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/filter").toTemplate())
//
//				.then().log().all()
//				.statusCode(200);

		title("Получение FormDocument c последним FormDocumentVersion");
		given().log().all().when()
				.header("Cookie",COOKIE)
				.param("filter[form_id]", 1)
				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/versions").toTemplate())

				.then().log().all()
				.statusCode(200);

		title("Получение FormDocument cо всеми доступными FormDocumentVersion по фильтру");
		given().log().all().when()
				.header("Cookie",COOKIE)
				.param("filter[form_id]", 1)
				.param("filter[form_document_id]", 3724)
				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/versions").toTemplate())

				.then().log().all()
				.statusCode(200);
	}

	@Test
	public void getActionShouldSendEmail(){

		title("dev2: Протокол испытаний  (flowable: Process identifier : forms-test): запускаем процесс");
		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/bp/start/47").toTemplate())
				.then().log().all()
				.statusCode(200);

		try {
			Thread.currentThread().sleep(1000*5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		title("dev2: Протокол испытаний  (flowable: Process identifier : forms-test) запускаем стрелку 'next'");
		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/actions/47/next").toTemplate())
				.then().log().all()
				.statusCode(200);

	}

	@Test
	public void getActionShouldWork(){



		title("dev2: Протокол испытаний  (flowable: Process identifier : forms-test) должен отсылать письмо  ");
		given().log().all().when()
				.header("Cookie",COOKIE)
				.get(UriBuilder.fromUri(HOST).path("/rest/form-document/actions/47/subTask2").toTemplate())
				.then().log().all()
				.statusCode(200);

	}

}

