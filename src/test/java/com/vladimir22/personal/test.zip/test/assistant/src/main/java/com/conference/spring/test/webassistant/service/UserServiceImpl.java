package com.conference.spring.test.webassistant.service;

import com.conference.spring.test.webassistant.persistence.User;
import com.conference.spring.test.webassistant.persistence.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository repository;

    @Override
    public User create(User user) {
        return repository.save(user);
    }

    @Override
    public User delete(int id) {
        User user = findById(id);
        if(user != null){
            repository.delete(user);
        }
        return user;
    }

    @Override
    public List<User> findAll() {
        return repository.findAll();
    }

    @Override
    public User findById(int id) {
        return repository.findOne(id);
    }

    @Override
    public User update(final int id, final User userApi) {
         User user  = findById(id);
        if (user == null) {
            return null;
        }
        user.setFirstName(userApi.getFirstName());
        user.setLastName(userApi.getLastName());

        repository.save(user);

        return user;

    }
}

