package com.conference.spring.test.webassistant.service;

import com.conference.spring.test.webassistant.persistence.User;

import java.util.List;

public interface UserService {

    User create(User user);

    User delete(int id);

    List<User> findAll();

    User findById(int id);

    User update(final int id, final User userApi);
}
