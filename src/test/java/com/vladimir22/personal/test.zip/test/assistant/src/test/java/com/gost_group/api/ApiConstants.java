package com.gost_group.api;

/**
 * @author v.pronkin on 01.08.2018
 */
public class ApiConstants {

	static final String  HOST = "http://localhost:9090";

//	static final String  HOST = "http://dev2.rsiek.gost-group.com";

	private static final String TITLE_MESSAGE = "\n\n------------------------ %s ------------------------";



	public static void title(String title){
		System.out.println(String.format(TITLE_MESSAGE, title));
	}


}
