package com.conference.spring.test.webassistant.service;

import org.springframework.boot.SpringBootConfiguration;

/**
 * @author tolkv
 * @version 03/04/2017
 */
@SpringBootConfiguration
public class StopConfiguration {
}
