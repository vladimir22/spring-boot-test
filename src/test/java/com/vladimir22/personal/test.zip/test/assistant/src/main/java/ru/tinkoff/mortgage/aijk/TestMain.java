package ru.tinkoff.mortgage.aijk;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;


/**
 * @author v.pronkin on 14.06.2018
 */


class TestMain {




	public static void main(String args[]) {
		System.out.println(String.format("~0b11100110\t\t\t= %s(%s)", Integer.toBinaryString(~0b11100110), ~0b11100110));
	}


}

