package ru.tinkoff.mortgage.aijk;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @author v.pronkin on 02.08.2018
 */
public class CvTasks {

	/**
	 * Написать программу, которая выводит числа от 1 до 100, но вместо чисел кратных 2 нужно выводить строку Two, вместо чисел кратных 7 - строку Seven,
	 * вместо чисел кратных 2 и 7 - строку TwoSeven.
	 */
	static void printNumbers() {

		IntStream.rangeClosed(1, 100).forEach((i) -> {

			StringBuilder sb = new StringBuilder();
			boolean isDefault = true;
			if (i % 2 == 0) {
				sb.append("Two");
				isDefault = false;
			}

			if (i % 7 == 0) {
				sb.append("Seven");
				isDefault = false;
			}

			if (isDefault) {
				sb.append(i);
			}

			System.out.println(sb.toString());
		});
	}

	/**
	 * Написать программу, вычисляющую для любых натуральных m и r, таких что r ≤ m, значение функции
	 * f(m,r)=m!/r!(m-r)!
	 */

	static BigInteger factorialByMethod(BigInteger n) {
		return n.compareTo(BigInteger.ZERO) == 0 ? BigInteger.ONE : n.multiply(factorialByMethod(n.subtract(BigInteger.ONE)));
	}

	static BigInteger factorialByStream(long n) {
		return Stream.iterate(BigInteger.ONE, i -> i.add(BigInteger.ONE))
				.limit(n)
				.reduce(BigInteger.ONE, (val, result) ->  result.multiply(val));
	}


	static void calculateFactorialFunction(long m, long r) {
		if (r > m) {
			throw new IllegalArgumentException(String.format("r : %d more than m : %d", r, m));
		}

		long diff = m - r;
		BigInteger result = factorialByMethod(BigInteger.valueOf(m)).divide(factorialByMethod(BigInteger.valueOf(r)).multiply(factorialByMethod(BigInteger.valueOf(diff))));
//		BigInteger result = factorialByStream(m).divide(factorialByStream(r).multiply(factorialByStream(diff)));

		System.out.println(String.format("f(%1$d,%2$d)=%1$d!/%2$d!(%1$d-%2$d)! = %3$d\n", m, r, result));
	}



	/**
	 * На вход программе подается литературный текст. Программа должна вывести список слов, встречающихся в тексте,
	 * в котором для каждого слова указывается количество вхождений этого слова в текст,
	 * а слова выводятся в порядке убывания частоты вхождения.
	 */

	static void calculateWords(String text) {

		String[] words = text.toLowerCase().split("[\\p{Punct}\\s]+");

		Arrays.stream(words)
				.collect(Collectors.groupingBy(s -> s)).entrySet().stream()
				.sorted(Comparator.comparing((Map.Entry<String, List<String>> e) -> e.getValue().size()).reversed())
				.forEach(entry -> System.out.println(String.format("%s : %d", entry.getKey(), entry.getValue().size())));
	}


	public static void main(String args[]) {

//		printNumbers();

//		calculateFactorialFunction(5, 4);
//		calculateFactorialFunction(501, 500);
//		calculateFactorialFunction(1, 1);
//		calculateFactorialFunction(9, 8);

		calculateWords("в котором для каждого слова указывается количество вхождений этого СЛОВА в текст");

	}
}