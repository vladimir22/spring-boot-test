package com.conference.spring.test.webassistant.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import ru.tinkoff.mortgage.aijk.token.model.PrepareTokenResponse;
import ru.tinkoff.mortgage.generated.aijk.model.CodeBaseDto;
import ru.tinkoff.mortgage.generated.aijk.model.FacadeFullApp;
import ru.tinkoff.mortgage.generated.aijk.model.FacadeFullAppApplicant;
import ru.tinkoff.mortgage.generated.aijk.model.FullAppAnswer;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

import static ru.tinkoff.mortgage.aijk.common.AijkObjectsHandler.assignContentUrl;
import static ru.tinkoff.mortgage.aijk.common.AijkObjectsHandler.attachFullAppPersonContent;
import static ru.tinkoff.mortgage.aijk.common.AijkObjectsHandlerTest.*;

/**
 * @author v.pronkin on 27.04.2018
 * example: http://localhost:8000/api/v1/fullApp/uid_1
 */
@Slf4j
@RestController
@RequestMapping({"/"})
public class AijkEmulatorController {


	private Map<String, FacadeFullAppApplicant> fullAppPersonMap;
	private Map<String, FacadeFullApp> fullAppMap;

	@PostConstruct
	public void init(){
		fullAppPersonMap = new HashMap<>();
		fullAppMap = new HashMap<>();
	}

	@GetMapping(path = {"api/v1/fullApp/{uid}"})
	public FacadeFullApp findFullApp(@PathVariable("uid") String uid){

		if (fullAppMap.containsKey(uid)){
			return fullAppMap.get(uid);
		} else{
			FacadeFullApp facadeFullApp = createFacadeFullApp(uid, "done");
			fullAppMap.put(uid,facadeFullApp);
			return facadeFullApp;
		}
	}

	@GetMapping(path = {"api/v1/fullApp/{uid}/applicant/{auid}"})
	public FacadeFullAppApplicant findFullAppApplicant(@PathVariable("uid") String uid, @PathVariable("auid") String auid){

		if (!fullAppPersonMap.containsKey(auid)){
			String documentId = String.join("_", uid, auid, "documentId");
			String contentUrl =String.join("_", documentId, "contentUrl");
			byte[] uploadContent = String.join("_", documentId, "uploadContent").getBytes();
			String contentType = "PDF";

			FacadeFullAppApplicant facadeFullAppPerson = createFacadeFullAppPerson(auid, documentId, contentType, uploadContent,contentUrl);

			String pendingSuffix="_UPLOADED";
			attachFullAppPersonContent(facadeFullAppPerson,documentId+pendingSuffix,contentType,uploadContent,contentUrl+pendingSuffix);

			fullAppPersonMap.put(auid,facadeFullAppPerson);

			prettyPrint("findFullAppApplicant, JSON_OUTPUT facadeFullAppPerson:", facadeFullAppPerson);
		}

		return fullAppPersonMap.get(auid);
	}

	@PutMapping(path = {"api/v1/fullApp/{uid}/applicant/{auid}"})
	public FullAppAnswer updateFullAppApplicant(@PathVariable("uid") String uid, @PathVariable("auid") String auid, @RequestBody FacadeFullAppApplicant facadeFullAppPerson, @RequestParam("documentsMergeStrategy") String documentsMergeStrategy){

		prettyPrint("updateFullAppApplicant, JSON_INPUT facadeFullAppPerson:", facadeFullAppPerson);

		assignContentUrl(facadeFullAppPerson);

		fullAppPersonMap.put(auid,facadeFullAppPerson);


		if (fullAppMap.containsKey(uid)){
			fullAppMap.get(uid).setStatus(new CodeBaseDto().name("inprogress"));

		} else{
			FacadeFullApp facadeFullApp = new FacadeFullApp();
			facadeFullApp.setUid(uid);
			facadeFullApp.setStatus(new CodeBaseDto().name("inprogress"));
			fullAppMap.put(uid, facadeFullApp);

		}


		return createFullAppAnswer(auid);
	}



	@PostMapping("api/v1/fullApp/{uid}/check")      // TODO MO-8: current swagger does not support this underwriting call
	public FullAppAnswer checkFullApp(@PathVariable("uid") String uid) throws InterruptedException {
		Thread.sleep(5*1000);
		prettyPrint("checkFullApp, JSON_OUTPUT uid:", uid);

	return createFullAppAnswer(uid);
	}



	
	@PostMapping(path="auth/realms/master/protocol/openid-connect/token")
	public PrepareTokenResponse getToken(@RequestParam("grant_type") String grantType,
	                                     @RequestParam("client_id") String clientId,
	                                     @RequestParam("client_secret") String clientSecret,
	                                     @RequestParam("scope") String scope,
	                                     @RequestParam("username") String userName,
	                                     @RequestParam("password") String password){


		return PrepareTokenResponse.builder().accessToken("accessToken_"+userName).idToken("idToken_"+userName).build();
		
	}

}
