package com.conference.spring.test.jbaruch;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;

/**
 * @author tolkv
 * @version 20/03/2017
 */
@Configuration
@EnableAutoConfiguration
public class Config {
}
