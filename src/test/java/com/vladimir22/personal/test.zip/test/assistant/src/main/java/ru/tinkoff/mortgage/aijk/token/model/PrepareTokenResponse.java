package ru.tinkoff.mortgage.aijk.token.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PrepareTokenResponse {
	@JsonProperty("access_token")
	private String accessToken;
	@JsonProperty("expires_in")
	private String expiresIn;
	@JsonProperty("refresh_expires_in")
	private String refreshExpiresIn;
	@JsonProperty("refresh_token")
	private String refreshToken;
	@JsonProperty("token_type")
	private String tokenType;
	@JsonProperty("id_token")
	private String idToken;
	@JsonProperty("not-before-policy")
	private String notBeforePolicy;
	@JsonProperty("session_state")
	private String sessionState;
}

