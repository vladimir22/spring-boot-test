package com.conference.spring.test.webassistant.controller;


import com.conference.spring.test.webassistant.persistence.User;
import com.conference.spring.test.webassistant.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static java.lang.Thread.sleep;
import static java.util.concurrent.CompletableFuture.supplyAsync;
import static java.util.stream.Collectors.toList;

//@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping({"/api"})
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public User create(@RequestBody User user){
        return userService.create(user);
    }

    @GetMapping(path = {"/{id}"})
    public User findOne(@PathVariable("id") int id){
        return userService.findById(id);
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<User> update(@PathVariable("id") final int id, @RequestBody User userApi){

        User user = userService.update(id, userApi);

        if (user == null) {
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8");
        headers.add(HttpHeaders.ACCEPT, "all");

        return  ResponseEntity.ok()
                .headers(headers)
                .body(user);
    }

    @DeleteMapping(path ={"/{id}"})
    public User delete(@PathVariable("id") int id) {
        return userService.delete(id);
    }

    @GetMapping
    public List<User> findAll(){
        return userService.findAll();
    }

    // Exercise using curl http://localhost:8000/async?input=lorem,ipsum,dolor,sit,amet
    @RequestMapping(path = "async", method = RequestMethod.GET)
    public CompletableFuture<String> get(@RequestParam List<String> input) throws Exception {
        return concatenateAsync(input);
    }

    private CompletableFuture<String> concatenateAsync(List<String> input) {

        List<CompletableFuture<String>> futures = input.stream().map(str -> supplyAsync(() -> callApi(str))).collect(toList());

        CompletableFuture<Void> jobsDone = CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()]));

        CompletableFuture<String> output = new CompletableFuture<>();

        // Once all of the futures have completed, build out the result string from results.
        jobsDone.thenAccept(ignored -> {
            StringBuilder stringBuilder = new StringBuilder();
            futures.forEach(f -> {
                try {
                    stringBuilder.append(f.get());
                } catch (Exception e) {
                    output.completeExceptionally(e);
                }
            });
            output.complete(stringBuilder.toString());
        });

        return output;
    }
    private String callApi(String str) {
        try {
            // restTemplate.invoke(...)
            sleep(1000);
        } catch (Exception e) {
        }
        return str.toUpperCase();
    }

}
