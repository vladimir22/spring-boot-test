package ru.tinkoff.mortgage.aijk.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import ru.tinkoff.mortgage.generated.aijk.model.CodeBaseDto;
import ru.tinkoff.mortgage.generated.aijk.model.FacadeFullApp;
import ru.tinkoff.mortgage.generated.aijk.model.FacadeFullAppApplicant;
import ru.tinkoff.mortgage.generated.aijk.model.FullAppAnswer;

import java.time.LocalDateTime;

import static ru.tinkoff.mortgage.aijk.common.AijkObjectsHandler.attachFullAppPersonContent;

/**
 * @author v.pronkin on 27.04.2018
 * used only in tests
 */
@Slf4j
public class AijkObjectsHandlerTest {


	public static FacadeFullApp createFacadeFullApp(String uid, String status){
		return createFacadeFullApp(uid, status, 0d, 0, 0d);
	}
	public static FacadeFullApp createFacadeFullApp(String uid, String status, Double creditAmount, Integer creditPeriod, Double interestPercent){

		FacadeFullApp facadeFullApp = new FacadeFullApp();
		facadeFullApp.setUid(uid);

		CodeBaseDto codeBaseDto = new CodeBaseDto();
		codeBaseDto.setName(status);
		facadeFullApp.setStatus(codeBaseDto);

		facadeFullApp.setCreditAmount(creditAmount);
		facadeFullApp.setCreditPeriod(creditPeriod);
		facadeFullApp.setInterestPercent(interestPercent);
		return facadeFullApp;
	}

	public static FacadeFullAppApplicant createFacadeFullAppPerson(String auid, String fileName, String contentType, byte[] uploadContent, String contentUrl){

		FacadeFullAppApplicant facadeFullAppPerson = new FacadeFullAppApplicant();
		facadeFullAppPerson.setUid(auid);

		attachFullAppPersonContent(facadeFullAppPerson, fileName, contentType, uploadContent, contentUrl);
		return facadeFullAppPerson;
	}

	public static FullAppAnswer createFullAppAnswer(String auid){

		FullAppAnswer fullAppAnswer = new FullAppAnswer();
		fullAppAnswer.setUid(auid);
		return fullAppAnswer;
	}

	public static void prettyPrint(String name, Object jsonObject) {
		try {
			String jsonInString = new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
			log.warn("{}:\n{}", name, jsonInString);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
}
